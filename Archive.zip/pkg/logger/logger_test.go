package logger

import (
	"bytes"
	"context"
	"log/slog"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNew(t *testing.T) {
	config := Config{
		Level:     slog.LevelInfo,
		Output:    &bytes.Buffer{},
		Format:    "json",
		AddSource: false,
		WithTime:  true,
	}

	logger := New(config)
	require.NotNil(t, logger, "New() should not return nil")
}

func TestNewWithOptions(t *testing.T) {
	logger := NewWithOptions(
		WithLevel(slog.LevelDebug),
		WithOutput(&bytes.Buffer{}),
		WithFormat("text"),
	)

	require.NotNil(t, logger, "NewWithOptions() should not return nil")
}

func TestNewWithFormat(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewWithFormat(buf, slog.LevelInfo, "json")

	require.NotNil(t, logger, "NewWithFormat() should not return nil")
}

func TestNewJSON(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewJSON(buf, slog.LevelInfo)

	require.NotNil(t, logger, "NewJSON() should not return nil")
}

func TestNewText(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewText(buf, slog.LevelInfo)

	require.NotNil(t, logger, "NewText() should not return nil")
}

func TestNewDefault(t *testing.T) {
	logger := NewDefault()
	require.NotNil(t, logger, "NewDefault() should not return nil")
}

func TestNewJSONDefault(t *testing.T) {
	logger := NewJSONDefault()
	require.NotNil(t, logger, "NewJSONDefault() should not return nil")
}

func TestNewTextDefault(t *testing.T) {
	logger := NewTextDefault()
	require.NotNil(t, logger, "NewTextDefault() should not return nil")
}

func TestLogger_Log(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewJSON(buf, slog.LevelInfo)

	ctx := context.Background()
	logger.Log(ctx, slog.LevelInfo, "test message", "key", "value")

	output := buf.String()
	assert.Contains(t, output, "test message", "Log output should contain 'test message'")
	assert.Contains(t, output, "key", "Log output should contain 'key'")
	assert.Contains(t, output, "value", "Log output should contain 'value'")
}

func TestLogger_Info(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewJSON(buf, slog.LevelInfo)

	logger.Info("info message", "key", "value")

	output := buf.String()
	assert.Contains(t, output, "info message", "Log output should contain 'info message'")
}

func TestLogger_Error(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewJSON(buf, slog.LevelError)

	logger.Error("error message", "key", "value")

	output := buf.String()
	assert.Contains(t, output, "error message", "Log output should contain 'error message'")
}

func TestLogger_Warn(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewJSON(buf, slog.LevelWarn)

	logger.Warn("warn message", "key", "value")

	output := buf.String()
	assert.Contains(t, output, "warn message", "Log output should contain 'warn message'")
}

func TestLogger_Debug(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewJSON(buf, slog.LevelDebug)

	logger.Debug("debug message", "key", "value")

	output := buf.String()
	assert.Contains(t, output, "debug message", "Log output should contain 'debug message'")
}

func TestLogger_ContextMethods(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewJSON(buf, slog.LevelDebug)
	ctx := context.Background()

	logger.InfoContext(ctx, "info context message")
	logger.ErrorContext(ctx, "error context message")
	logger.WarnContext(ctx, "warn context message")
	logger.DebugContext(ctx, "debug context message")

	output := buf.String()
	assert.Contains(t, output, "info context message", "Should contain info context message")
	assert.Contains(t, output, "error context message", "Should contain error context message")
	assert.Contains(t, output, "warn context message", "Should contain warn context message")
	assert.Contains(t, output, "debug context message", "Should contain debug context message")
}

func TestNoOpLogger(t *testing.T) {
	logger := NoOpLogger()
	require.NotNil(t, logger, "NoOpLogger() should not return nil")

	// No-op logger should not panic
	logger.Info("test")
	logger.Error("test")
	logger.Warn("test")
	logger.Debug("test")
}

func TestDefaultConfig(t *testing.T) {
	config := DefaultConfig()

	assert.Equal(t, slog.LevelInfo, config.Level, "Default level should be Info")
	assert.Equal(t, "json", config.Format, "Default format should be 'json'")
	assert.True(t, config.WithTime, "WithTime should be true by default")
	assert.Equal(t, time.RFC3339, config.TimeFormat, "Default time format should be RFC3339")
}

func TestWithContext(t *testing.T) {
	buf := &bytes.Buffer{}
	logger := NewJSON(buf, slog.LevelInfo)
	ctx := context.Background()

	result := WithContext(ctx, logger)
	require.NotNil(t, result, "WithContext() should not return nil")

	// For now, WithContext just returns the logger as is
	assert.Equal(t, logger, result, "WithContext() should return the same logger instance")
}
