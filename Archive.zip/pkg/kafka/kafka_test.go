package kafka

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/twmb/franz-go/pkg/sasl/plain"
)

func TestNew(t *testing.T) {
	// This test would require a running Kafka broker
	// For unit tests, we'll skip the actual client creation
	t.Skip("Skipping test that requires Kafka broker")
}

func TestNewWithConfig(t *testing.T) {
	config := Config{
		Brokers:                []string{"localhost:9092"},
		ConsumerGroup:          "test-group",
		ClientID:               "test-client",
		MaxConcurrentFetches:   10,
		AllowAutoTopicCreation: true,
		MetadataMaxAge:         5 * time.Minute,
		RequestRetries:         3,
		DialTimeout:            10 * time.Second,
		RetryTimeout:           30 * time.Second,
		ConnIdleTimeout:        5 * time.Minute,
		SASLMechanism:          plain.Auth{User: "user", Pass: "pass"}.AsMechanism(),
	}

	// This would require a running Kafka broker
	// For unit tests, we'll just test that the config is valid
	assert.NotEmpty(t, config.Brokers, "Brokers should not be empty")
	assert.NotEmpty(t, config.ConsumerGroup, "ConsumerGroup should not be empty")
}

func TestWithBrokers(t *testing.T) {
	brokers := []string{"localhost:9092", "localhost:9093"}
	opt := WithBrokers(brokers...)

	// We can't directly test the kgo.Opt, but we can ensure it's not nil
	require.NotNil(t, opt, "WithBrokers should return a valid option")
}

func TestWithConsumerGroup(t *testing.T) {
	group := "test-group"
	opt := WithConsumerGroup(group)

	require.NotNil(t, opt, "WithConsumerGroup should return a valid option")
}

func TestWithClientID(t *testing.T) {
	clientID := "test-client"
	opt := WithClientID(clientID)

	require.NotNil(t, opt, "WithClientID should return a valid option")
}

func TestWithSASL(t *testing.T) {
	mechanism := plain.Auth{User: "user", Pass: "pass"}.AsMechanism()
	opt := WithSASL(mechanism)

	require.NotNil(t, opt, "WithSASL should return a valid option")
}

func TestWithMaxConcurrentFetches(t *testing.T) {
	max := 10
	opt := WithMaxConcurrentFetches(max)

	require.NotNil(t, opt, "WithMaxConcurrentFetches should return a valid option")
}

func TestWithAllowAutoTopicCreation(t *testing.T) {
	opt := WithAllowAutoTopicCreation()

	require.NotNil(t, opt, "WithAllowAutoTopicCreation should return a valid option")
}

func TestWithMetadataMaxAge(t *testing.T) {
	age := 5 * time.Minute
	opt := WithMetadataMaxAge(age)

	require.NotNil(t, opt, "WithMetadataMaxAge should return a valid option")
}

func TestWithRequestRetries(t *testing.T) {
	n := 3
	opt := WithRequestRetries(n)

	require.NotNil(t, opt, "WithRequestRetries should return a valid option")
}

func TestWithDialTimeout(t *testing.T) {
	timeout := 10 * time.Second
	opt := WithDialTimeout(timeout)

	require.NotNil(t, opt, "WithDialTimeout should return a valid option")
}

func TestWithRetryTimeout(t *testing.T) {
	timeout := 30 * time.Second
	opt := WithRetryTimeout(timeout)

	require.NotNil(t, opt, "WithRetryTimeout should return a valid option")
}

func TestWithConnIdleTimeout(t *testing.T) {
	timeout := 5 * time.Minute
	opt := WithConnIdleTimeout(timeout)

	require.NotNil(t, opt, "WithConnIdleTimeout should return a valid option")
}

func TestConfig(t *testing.T) {
	config := Config{
		Brokers:                []string{"localhost:9092"},
		ConsumerGroup:          "test-group",
		ClientID:               "test-client",
		MaxConcurrentFetches:   10,
		AllowAutoTopicCreation: true,
		MetadataMaxAge:         5 * time.Minute,
		RequestRetries:         3,
		DialTimeout:            10 * time.Second,
		RetryTimeout:           30 * time.Second,
		ConnIdleTimeout:        5 * time.Minute,
	}

	assert.Len(t, config.Brokers, 1, "Expected 1 broker")
	assert.Equal(t, "test-group", config.ConsumerGroup, "Expected correct consumer group")
	assert.Equal(t, "test-client", config.ClientID, "Expected correct client ID")
	assert.Equal(t, 10, config.MaxConcurrentFetches, "Expected correct max concurrent fetches")
	assert.True(t, config.AllowAutoTopicCreation, "Expected AllowAutoTopicCreation to be true")
	assert.Equal(t, 5*time.Minute, config.MetadataMaxAge, "Expected correct metadata max age")
	assert.Equal(t, 3, config.RequestRetries, "Expected correct request retries")
	assert.Equal(t, 10*time.Second, config.DialTimeout, "Expected correct dial timeout")
	assert.Equal(t, 30*time.Second, config.RetryTimeout, "Expected correct retry timeout")
	assert.Equal(t, 5*time.Minute, config.ConnIdleTimeout, "Expected correct conn idle timeout")
}
