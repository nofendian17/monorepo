package postgres

import (
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func TestNewPostgresClient_WithMock(t *testing.T) {
	sqlDB, mock, err := sqlmock.New()
	require.NoError(t, err, "Failed to create sqlmock")
	defer sqlDB.Close()

	// Mock the ping that happens in NewPostgresClient
	mock.ExpectPing()

	// Create a config for testing
	config := Config{
		Host:            "localhost",
		Port:            5432,
		User:            "postgres",
		Password:        "password",
		DBName:          "testdb",
		Schema:          "public",
		SSLMode:         "disable",
		MaxIdleConns:    10,
		MaxOpenConns:    100,
		ConnMaxIdleTime: 5,
		ConnMaxLifetime: 60,
		Debug:           false,
	}

	// We can't easily test NewPostgresClient directly since it creates its own connection
	// But we can test that the config is valid
	assert.Equal(t, "localhost", config.Host, "Config validation failed")
}

func setupMockPostgres(t *testing.T) (PostgresClient, sqlmock.Sqlmock) {
	sqlDB, mock, err := sqlmock.New()
	require.NoError(t, err, "Failed to create sqlmock")

	// Mock the ping
	mock.ExpectPing()

	// Open GORM with the mocked database
	dialector := postgres.New(postgres.Config{
		Conn:                 sqlDB,
		PreferSimpleProtocol: true,
	})

	db, err := gorm.Open(dialector, &gorm.Config{})
	require.NoError(t, err, "Failed to open GORM with mock")

	client := &postgresClient{
		DB: db,
	}

	t.Cleanup(func() {
		sqlDB.Close()
	})

	return client, mock
}

func TestPostgresClient_Migrate(t *testing.T) {
	client, mock := setupMockPostgres(t)

	// Mock GORM's table existence check for users
	mock.ExpectQuery(`SELECT count\(\*\) FROM information_schema\.tables WHERE table_schema = CURRENT_SCHEMA\(\) AND table_name = \$1 AND table_type = \$2`).
		WithArgs("users", "BASE TABLE").
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))

	// Mock the users table creation
	mock.ExpectExec(`CREATE TABLE "users"`).
		WillReturnResult(sqlmock.NewResult(1, 1))

	// Mock GORM's table existence check for posts
	mock.ExpectQuery(`SELECT count\(\*\) FROM information_schema\.tables WHERE table_schema = CURRENT_SCHEMA\(\) AND table_name = \$1 AND table_type = \$2`).
		WithArgs("posts", "BASE TABLE").
		WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))

	// Mock the posts table creation
	mock.ExpectExec(`CREATE TABLE "posts"`).
		WillReturnResult(sqlmock.NewResult(1, 1))

	// Define models for testing
	type User struct {
		ID   uint   `gorm:"primaryKey"`
		Name string `gorm:"size:100"`
	}

	type Post struct {
		ID     uint   `gorm:"primaryKey"`
		Title  string `gorm:"size:200"`
		UserID uint
		User   User `gorm:"constraint:OnUpdate:CASCADE,OnDelete:SET NULL;"`
	}

	err := client.Migrate(&User{}, &Post{})
	require.NoError(t, err, "Migrate() should not fail")

	require.NoError(t, mock.ExpectationsWereMet(), "SQL expectations should be met")
}

func TestPostgresClient_GetDB(t *testing.T) {
	client, _ := setupMockPostgres(t)

	db := client.GetDB()
	require.NotNil(t, db, "GetDB() should not return nil")
}

func TestPostgresClient_Close(t *testing.T) {
	client, mock := setupMockPostgres(t)

	// Mock the close operation
	mock.ExpectClose()

	err := client.Close()
	require.NoError(t, err, "Close() should not fail")

	require.NoError(t, mock.ExpectationsWereMet(), "SQL expectations should be met")
}

func TestConfig(t *testing.T) {
	config := Config{
		Host:            "localhost",
		Port:            5432,
		User:            "postgres",
		Password:        "password",
		DBName:          "testdb",
		Schema:          "public",
		SSLMode:         "disable",
		MaxIdleConns:    10,
		MaxOpenConns:    100,
		ConnMaxIdleTime: 5,
		ConnMaxLifetime: 60,
		Debug:           false,
	}

	assert.Equal(t, "localhost", config.Host, "Expected correct host")
	assert.Equal(t, 5432, config.Port, "Expected correct port")
	assert.Equal(t, "postgres", config.User, "Expected correct user")
	assert.Equal(t, "password", config.Password, "Expected correct password")
	assert.Equal(t, "testdb", config.DBName, "Expected correct dbname")
	assert.Equal(t, "public", config.Schema, "Expected correct schema")
	assert.Equal(t, "disable", config.SSLMode, "Expected correct sslmode")
	assert.Equal(t, 10, config.MaxIdleConns, "Expected correct max idle conns")
	assert.Equal(t, 100, config.MaxOpenConns, "Expected correct max open conns")
	assert.Equal(t, 5, config.ConnMaxIdleTime, "Expected correct conn max idle time")
	assert.Equal(t, 60, config.ConnMaxLifetime, "Expected correct conn max lifetime")
	assert.False(t, config.Debug, "Expected debug to be false")
}
