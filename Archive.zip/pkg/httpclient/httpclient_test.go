package httpclient

import (
	"context"
	"encoding/json"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNew(t *testing.T) {
	client := New()
	require.NotNil(t, client, "New() should not return nil")

	assert.Equal(t, "", client.BaseURL(), "Expected empty base URL")
	assert.Equal(t, 30*time.Second, client.Timeout(), "Expected timeout 30s")
}

func TestWithBaseURL(t *testing.T) {
	baseURL := "https://api.example.com"
	client := New(WithBaseURL(baseURL))

	assert.Equal(t, baseURL, client.BaseURL(), "Expected correct base URL")
}

func TestWithTimeout(t *testing.T) {
	timeout := 10 * time.Second
	client := New(WithTimeout(timeout))

	assert.Equal(t, timeout, client.Timeout(), "Expected correct timeout")
}

func TestWithHeaders(t *testing.T) {
	headers := map[string]string{
		"Authorization": "Bearer token",
		"Content-Type":  "application/json",
	}

	client := New(WithHeaders(headers))

	// We can't directly test the headers map, but we can test that the client was created
	require.NotNil(t, client, "Client should not be nil")
}

func TestWithRetryCount(t *testing.T) {
	retryCount := 3
	client := New(WithRetryCount(retryCount))

	assert.Equal(t, retryCount, client.RetryCount(), "Expected correct retry count")
}

func TestWithLogger(t *testing.T) {
	logger := slog.New(slog.NewTextHandler(nil, nil))
	client := New(WithLogger(logger))

	assert.Equal(t, logger, client.Logger(), "Logger should be set")
}

func TestClient_Get(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, http.MethodGet, r.Method, "Expected GET method")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	}))
	defer server.Close()

	client := New(WithBaseURL(server.URL))
	resp, err := client.Get(context.Background(), "/", nil)
	require.NoError(t, err, "Get() should not fail")
	defer resp.Body.Close()

	assert.Equal(t, http.StatusOK, resp.StatusCode, "Expected status 200")
}

func TestClient_Post(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, http.MethodPost, r.Method, "Expected POST method")
		assert.Equal(t, "application/json", r.Header.Get("Content-Type"), "Expected Content-Type application/json")
		w.WriteHeader(http.StatusCreated)
		w.Write([]byte("Created"))
	}))
	defer server.Close()

	client := New(WithBaseURL(server.URL))
	data := map[string]string{"key": "value"}
	resp, err := client.Post(context.Background(), "/", data, nil)
	require.NoError(t, err, "Post() should not fail")
	defer resp.Body.Close()

	assert.Equal(t, http.StatusCreated, resp.StatusCode, "Expected status 201")
}

func TestClient_Put(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, http.MethodPut, r.Method, "Expected PUT method")
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()

	client := New(WithBaseURL(server.URL))
	data := map[string]string{"key": "value"}
	resp, err := client.Put(context.Background(), "/", data, nil)
	require.NoError(t, err, "Put() should not fail")
	defer resp.Body.Close()

	assert.Equal(t, http.StatusOK, resp.StatusCode, "Expected status 200")
}

func TestClient_Delete(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, http.MethodDelete, r.Method, "Expected DELETE method")
		w.WriteHeader(http.StatusNoContent)
	}))
	defer server.Close()

	client := New(WithBaseURL(server.URL))
	resp, err := client.Delete(context.Background(), "/", nil)
	require.NoError(t, err, "Delete() should not fail")
	defer resp.Body.Close()

	assert.Equal(t, http.StatusNoContent, resp.StatusCode, "Expected status 204")
}

func TestClient_GetJSON(t *testing.T) {
	expectedData := map[string]string{"message": "success"}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(expectedData)
	}))
	defer server.Close()

	client := New(WithBaseURL(server.URL))
	var result map[string]string
	err := client.GetJSON(context.Background(), "/", &result, nil)
	require.NoError(t, err, "GetJSON() should not fail")

	assert.Equal(t, "success", result["message"], "Expected correct message")
}

func TestClient_PostJSON(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var requestData map[string]string
		json.NewDecoder(r.Body).Decode(&requestData)

		assert.Equal(t, "test", requestData["input"], "Expected correct input")

		responseData := map[string]string{"output": "result"}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(responseData)
	}))
	defer server.Close()

	client := New(WithBaseURL(server.URL))
	inputData := map[string]string{"input": "test"}
	var result map[string]string
	err := client.PostJSON(context.Background(), "/", inputData, &result, nil)
	require.NoError(t, err, "PostJSON() should not fail")

	assert.Equal(t, "result", result["output"], "Expected correct output")
}

func TestClient_Do(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		assert.Equal(t, "PATCH", r.Method, "Expected PATCH method")
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()

	client := New(WithBaseURL(server.URL))
	resp, err := client.Do(context.Background(), "PATCH", "/", nil, nil)
	require.NoError(t, err, "Do() should not fail")
	defer resp.Body.Close()

	assert.Equal(t, http.StatusOK, resp.StatusCode, "Expected status 200")
}
