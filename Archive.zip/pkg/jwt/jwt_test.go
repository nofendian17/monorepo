package jwt

import (
	"context"
	"sync"
	"testing"
	"time"

	goredis "github.com/redis/go-redis/v9"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// Test data constants
const (
	testUserID    = "user123"
	testAgentID   = "agent123"
	testAgentType = "IATA"
)

var (
	testAccessSecret  = "access-secret-key"
	testRefreshSecret = "refresh-secret-key"
	testAccessExpiry  = time.Minute * 15
	testRefreshExpiry = time.Hour * 24 * 7
)

// Helper function to create a stateless JWT manager for testing
func createTestJWTManager(t *testing.T) *Client {
	t.Helper()
	jwtManager, err := NewStateless(
		WithAccessTokenSecret(testAccessSecret),
		WithRefreshTokenSecret(testRefreshSecret),
		WithAccessTokenExpiry(testAccessExpiry),
		WithRefreshTokenExpiry(testRefreshExpiry),
		WithStateful(false),
	)
	if err != nil {
		t.Fatalf("Failed to create JWT manager: %v", err)
	}
	return jwtManager.(*Client)
}

// Helper function to assert token claims
func assertTokenClaims(t *testing.T, claims *TokenClaims, expectedUserID, expectedAgentID, expectedAgentType, expectedTokenType string) {
	t.Helper()

	assert.Equal(t, expectedUserID, claims.UserID, "UserID should match")
	assert.Equal(t, expectedAgentID, claims.AgentID, "AgentID should match")
	assert.Equal(t, expectedAgentType, claims.AgentType, "AgentType should match")
	assert.Equal(t, expectedTokenType, claims.TokenType, "TokenType should match")
}

func TestAccessTokenGenerationAndValidation(t *testing.T) {
	jwtManager := createTestJWTManager(t)

	tokenString, err := jwtManager.GenerateAccessToken(testUserID, testAgentID, testAgentType)
	require.NoError(t, err, "GenerateAccessToken should not return error")
	require.NotEmpty(t, tokenString, "Generated token should not be empty")

	claims, err := jwtManager.ValidateAccessToken(tokenString)
	require.NoError(t, err, "ValidateAccessToken should not return error")
	require.NotNil(t, claims, "Claims should not be nil")

	assertTokenClaims(t, claims, testUserID, testAgentID, testAgentType, TokenTypeAccess)
}

func TestRefreshTokenGenerationAndValidation(t *testing.T) {
	jwtManager := createTestJWTManager(t)

	tokenString, err := jwtManager.GenerateRefreshToken(testUserID, testAgentID, testAgentType)
	require.NoError(t, err, "GenerateRefreshToken should not return error")
	require.NotEmpty(t, tokenString, "Generated token should not be empty")

	claims, err := jwtManager.ValidateRefreshToken(tokenString)
	require.NoError(t, err, "ValidateRefreshToken should not return error")
	require.NotNil(t, claims, "Claims should not be nil")

	// Refresh tokens don't include agent info
	assert.Equal(t, testUserID, claims.UserID, "UserID should match")
	assert.Equal(t, TokenTypeRefresh, claims.TokenType, "TokenType should be refresh")
}

func TestRefreshAccessToken(t *testing.T) {
	jwtManager := createTestJWTManager(t)

	refreshToken, err := jwtManager.GenerateRefreshToken(testUserID, testAgentID, testAgentType)
	require.NoError(t, err, "GenerateRefreshToken should not return error")
	require.NotEmpty(t, refreshToken, "Generated refresh token should not be empty")

	newAccessToken, err := jwtManager.RefreshAccessToken(refreshToken)
	require.NoError(t, err, "RefreshAccessToken should not return error")
	require.NotEmpty(t, newAccessToken, "New access token should not be empty")

	claims, err := jwtManager.ValidateAccessToken(newAccessToken)
	require.NoError(t, err, "ValidateAccessToken should not return error")
	require.NotNil(t, claims, "Claims should not be nil")

	// Note: Refresh tokens don't contain agent information, so refreshed access tokens won't either
	assert.Equal(t, testUserID, claims.UserID, "UserID should match")
	assert.Equal(t, TokenTypeAccess, claims.TokenType, "TokenType should be access")
}

func TestInvalidToken(t *testing.T) {
	jwtManager := createTestJWTManager(t)

	_, err := jwtManager.ValidateAccessToken("invalid.token.string")
	assert.Error(t, err, "ValidateAccessToken should return error for invalid token")
}

func TestWrongTokenType(t *testing.T) {
	jwtManager := createTestJWTManager(t)

	refreshToken, err := jwtManager.GenerateRefreshToken(testUserID, testAgentID, testAgentType)
	require.NoError(t, err, "GenerateRefreshToken should not return error")

	// Try to validate refresh token as access token (should fail)
	_, err = jwtManager.ValidateAccessToken(refreshToken)
	assert.Error(t, err, "ValidateAccessToken should return error for wrong token type")
}

func TestTokenExpiry(t *testing.T) {
	jwtManager, err := NewStateless(
		WithAccessTokenSecret("access-secret-key"),
		WithRefreshTokenSecret("refresh-secret-key"),
		WithAccessTokenExpiry(time.Second*1),
		WithRefreshTokenExpiry(time.Second*2),
		WithStateful(false),
	)
	require.NoError(t, err, "NewStateless should not return error")

	tokenString, err := jwtManager.GenerateAccessToken("user123", "agent123", "user")
	require.NoError(t, err, "GenerateAccessToken should not return error")

	// Sleep for more than token expiry time
	time.Sleep(1100 * time.Millisecond)

	_, err = jwtManager.ValidateAccessToken(tokenString)
	assert.Error(t, err, "ValidateAccessToken should return error for expired token")
}

func TestStatefulRevokeErrors(t *testing.T) {
	t.Run("RevokeRefreshToken should fail in stateless mode", func(t *testing.T) {
		jwtManager, err := NewStateless(
			WithAccessTokenSecret("access-secret-key"),
			WithRefreshTokenSecret("refresh-secret-key"),
			WithAccessTokenExpiry(time.Minute*15),
			WithRefreshTokenExpiry(time.Hour*24*7),
			WithStateful(false), // Stateless mode
		)
		require.NoError(t, err, "NewStateless should not return error")

		err = jwtManager.RevokeRefreshToken("user123", "token123")
		assert.Error(t, err, "RevokeRefreshToken should return error in stateless mode")
	})

	t.Run("RevokeAllRefreshTokens should fail in stateless mode", func(t *testing.T) {
		jwtManager, err := NewStateless(
			WithAccessTokenSecret("access-secret-key"),
			WithRefreshTokenSecret("refresh-secret-key"),
			WithAccessTokenExpiry(time.Minute*15),
			WithRefreshTokenExpiry(time.Hour*24*7),
			WithStateful(false), // Stateless mode
		)
		require.NoError(t, err, "NewStateless should not return error")

		err = jwtManager.RevokeAllRefreshTokens("user123")
		assert.Error(t, err, "RevokeAllRefreshTokens should return error in stateless mode")
	})
}

func TestTokenExpirationUtilities(t *testing.T) {
	jwtManager := createTestJWTManager(t)

	t.Run("GetTokenExpiration should return correct expiration time", func(t *testing.T) {
		tokenString, err := jwtManager.GenerateAccessToken(testUserID, testAgentID, testAgentType)
		require.NoError(t, err, "GenerateAccessToken should not return error")

		expiry, err := jwtManager.GetTokenExpiration(tokenString)
		require.NoError(t, err, "GetTokenExpiration should not return error")

		// Expiration should be approximately testAccessExpiry from now
		expectedExpiry := time.Now().Add(testAccessExpiry)
		assert.WithinDuration(t, expectedExpiry, expiry, time.Second*5, "Expiration time should be approximately correct")
	})

	t.Run("GetTokenRemainingTime should return positive duration for valid token", func(t *testing.T) {
		tokenString, err := jwtManager.GenerateAccessToken(testUserID, testAgentID, testAgentType)
		require.NoError(t, err, "GenerateAccessToken should not return error")

		remaining, err := jwtManager.GetTokenRemainingTime(tokenString)
		require.NoError(t, err, "GetTokenRemainingTime should not return error")

		assert.True(t, remaining > 0, "Remaining time should be positive for valid token")
		assert.True(t, remaining <= testAccessExpiry, "Remaining time should be less than or equal to expiry duration")
	})

	t.Run("IsTokenExpired should return false for valid token", func(t *testing.T) {
		tokenString, err := jwtManager.GenerateAccessToken(testUserID, testAgentID, testAgentType)
		require.NoError(t, err, "GenerateAccessToken should not return error")

		expired, err := jwtManager.IsTokenExpired(tokenString)
		require.NoError(t, err, "IsTokenExpired should not return error")

		assert.False(t, expired, "Token should not be expired")
	})

	t.Run("IsTokenExpired should return true for expired token", func(t *testing.T) {
		jwtManager, err := NewStateless(
			WithAccessTokenSecret("access-secret-key"),
			WithRefreshTokenSecret("refresh-secret-key"),
			WithAccessTokenExpiry(time.Second*1),
			WithRefreshTokenExpiry(time.Second*2),
			WithStateful(false),
		)
		require.NoError(t, err, "NewStateless should not return error")

		tokenString, err := jwtManager.GenerateAccessToken("user123", "agent123", "user")
		require.NoError(t, err, "GenerateAccessToken should not return error")

		// Wait for token to expire
		time.Sleep(1100 * time.Millisecond)

		expired, err := jwtManager.IsTokenExpired(tokenString)
		// For expired tokens, the JWT library returns a validation error
		// So we expect an error here, which means the token is effectively expired
		assert.Error(t, err, "IsTokenExpired should return error for expired token")
		assert.False(t, expired, "Expired should be false when there's an error")
	})

	t.Run("Expiration utilities should return error for invalid token", func(t *testing.T) {
		jwtManager := createTestJWTManager(t)

		_, err := jwtManager.GetTokenExpiration("invalid.token")
		assert.Error(t, err, "GetTokenExpiration should return error for invalid token")

		_, err = jwtManager.GetTokenRemainingTime("invalid.token")
		assert.Error(t, err, "GetTokenRemainingTime should return error for invalid token")

		_, err = jwtManager.IsTokenExpired("invalid.token")
		assert.Error(t, err, "IsTokenExpired should return error for invalid token")
	})
}

func TestTokenGenerationAndValidation(t *testing.T) {
	jwtManager := createTestJWTManager(t)

	tests := []struct {
		name           string
		tokenType      string
		generateFunc   func() (string, error)
		validateFunc   func(string) (*TokenClaims, error)
		expectedClaims func(*TokenClaims)
	}{
		{
			name:         "access token",
			tokenType:    "access",
			generateFunc: func() (string, error) { return jwtManager.GenerateAccessToken(testUserID, testAgentID, testAgentType) },
			validateFunc: jwtManager.ValidateAccessToken,
			expectedClaims: func(claims *TokenClaims) {
				assertTokenClaims(t, claims, testUserID, testAgentID, testAgentType, TokenTypeAccess)
			},
		},
		{
			name:         "refresh token",
			tokenType:    "refresh",
			generateFunc: func() (string, error) { return jwtManager.GenerateRefreshToken(testUserID, testAgentID, testAgentType) },
			validateFunc: jwtManager.ValidateRefreshToken,
			expectedClaims: func(claims *TokenClaims) {
				assert.Equal(t, testUserID, claims.UserID, "UserID should match")
				assert.Equal(t, TokenTypeRefresh, claims.TokenType, "TokenType should be refresh")
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tokenString, err := tt.generateFunc()
			require.NoError(t, err, "Token generation should not return error")
			require.NotEmpty(t, tokenString, "Generated token should not be empty")

			claims, err := tt.validateFunc(tokenString)
			require.NoError(t, err, "Token validation should not return error")
			require.NotNil(t, claims, "Claims should not be nil")

			tt.expectedClaims(claims)
		})
	}
}

// MockRedisClient is a mock implementation of the redis.Client for testing
type MockRedisClient struct {
	mu   sync.RWMutex
	data map[string]map[string]interface{}
	ttls map[string]time.Time
}

func NewMockRedisClient() *MockRedisClient {
	return &MockRedisClient{
		data: make(map[string]map[string]interface{}),
		ttls: make(map[string]time.Time),
	}
}

// Implement the methods used by JWT client
func (m *MockRedisClient) HMSet(ctx context.Context, key string, values map[string]interface{}) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	if m.data[key] == nil {
		m.data[key] = make(map[string]interface{})
	}
	for k, v := range values {
		m.data[key][k] = v
	}
	return nil
}

func (m *MockRedisClient) Expire(ctx context.Context, key string, expiration time.Duration) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	m.ttls[key] = time.Now().Add(expiration)
	return nil
}

func (m *MockRedisClient) Exists(ctx context.Context, key string) (bool, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	_, exists := m.data[key]
	return exists, nil
}

func (m *MockRedisClient) HMGet(ctx context.Context, key string, fields ...string) ([]interface{}, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	if m.data[key] == nil {
		result := make([]interface{}, len(fields))
		for i := range result {
			result[i] = nil
		}
		return result, nil
	}

	result := make([]interface{}, len(fields))
	for i, field := range fields {
		result[i] = m.data[key][field]
	}
	return result, nil
}

func (m *MockRedisClient) HSet(ctx context.Context, key, field string, value interface{}) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	if m.data[key] == nil {
		m.data[key] = make(map[string]interface{})
	}
	m.data[key][field] = value
	return nil
}

func (m *MockRedisClient) HGet(ctx context.Context, key, field string) (string, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	if m.data[key] == nil {
		return "", goredis.Nil
	}

	if value, exists := m.data[key][field]; exists {
		if str, ok := value.(string); ok {
			return str, nil
		}
		return "", goredis.Nil
	}
	return "", goredis.Nil
}

func (m *MockRedisClient) GetClient() goredis.UniversalClient {
	// For testing, we'll return nil and handle this in the JWT client
	// This is a limitation - proper mocking would require interface-based design
	return nil
}

// Helper function to create a stateful JWT manager with mocked Redis for testing
func createTestStatefulJWTManager(t *testing.T) *Client {
	t.Helper()

	// For now, skip Redis-dependent tests
	// TODO: Implement proper Redis mocking by creating an interface in the JWT package
	t.Skip("Stateful JWT tests require Redis mocking - interface-based design needed")

	return nil
}
